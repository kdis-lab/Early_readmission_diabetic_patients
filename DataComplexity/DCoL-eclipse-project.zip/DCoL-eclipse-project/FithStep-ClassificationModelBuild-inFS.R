library(caret)
#library(ggplot2)
#library(plotROC)
#library(pROC)
#library(ROCR)

setwd("/home/ogreyes/Diabetes-paper/")

source("Functions.R")

#Not available in Windows
library(doMC)
registerDoMC(cores = 12)
## All subsequent models are then run in parallel

#Required packages

mydata <- read.csv("diabetic_data-fourthStep-preproc.csv")

wants <- c("caret", "adabag", "bartMachine", "bst", "C50", "deepboost","earth","evtree", "extraTrees",
           "gbm", "glmnet", "inTrees", "mda", "nodeHarvest", "pamr", "penalizedLDA", "party", "plyr", "mboost", 
           "Matrix", "MASS", "ordinalNet", "obliqueRF", "rFerns", "randomForest", "RWeka", 
           "rotationForest","rpart", "RRF", "sparseLDA", "wsrf", "xgboost", "ROCR", "Metrics")

has   <- wants %in% rownames(installed.packages())

#if(any(!has)) install.packages(wants[!has])

algorithms <- c("rf","AdaBoost.M1", "AdaBag", "bagEarth", "bagFDA", "bartMachine", "BstLm", "bstSm", "C5.0",
                "cforest", "ctree", "deepboost","extraTrees", "gamboost", "gbm", "glmnet",
                "J48", "JRip", "PART", "LMT", "nodeHarvest", "ordinalNet", "ORFlog", "ORFpls", "ORFridge",
                "ORFsvm", "pam", "PenalizedLDA", "wsrf", "rFerns", "rpart", "rpartCost", "RRF", "sparseLDA",
                "xgbLinear", "xgbTree")

set.seed(825)

# To create a stratified repeated k-fold cross validation
multiIndexes<-createMultiFolds(y=mydata$readmitted, k = 10, times = 3)

#we use an automatic grid by means of using the parameter tunelength
# see http://machinelearningmastery.com/tuning-machine-learning-models-using-the-caret-r-package/

fitControl <- trainControl(method="repeatedcv", number=10, repeats = 3, index = multiIndexes, classProbs=TRUE,
                    savePredictions = TRUE, search="grid", allowParallel= TRUE, summaryFunction = multiClassSummary, verboseIter = FALSE)

#execute the algorithms
for(algorithm in algorithms){

  modelFit <- train(readmitted ~ ., data = mydata, 
                    method=algorithm,
                    metric = "AUC",
                    maximize = TRUE,
                    tuneLength = 10,
                    trControl = fitControl)
  
  #cNameTuning <-colnames(modelFit$bestTune)
  
  # Maybe, there is a better way to do this filter of results
  #strFilter <- ""
  
  #for(nameParameter in cNameTuning){
  
  # strFilter <- paste(strFilter, " (modelFit$results[,\"",nameParameter,"\"] == modelFit$bestTune[,\"",nameParameter,"\"]) &", sep = "")
  
  #}
  
  #strFilter <- substr(strFilter, 1, nchar(strFilter)-1)
  
  #indexes <- eval(parse(text=strFilter))
  
  #results <- modelFit$results[indexes,]
  
  #results <- modelFit$results[as.integer(rownames(modelFit$bestTune)[1]),]
  
  #Saving all the results
  write.table(modelFit$results, file= paste("results-classification/results-",algorithm, ".csv", sep = ""),
              quote = FALSE, sep="," , row.names = FALSE, col.names = TRUE, na = "")
  
  #Saving the variable importance
  varImportance <- varImp(modelFit, scale=FALSE)
  
  write.table(varImportance$importance, file= paste("results-classification/varImportance-",algorithm, ".csv", sep = ""),
              quote = FALSE, sep="," , row.names = TRUE, col.names = TRUE, na = "")
  
  #Saving the model for graphing plots a posteriory.
  # save the model to disk
  saveRDS(modelFit, paste("results-classification/modelfit-",algorithm, ".rds", sep = ""))
  
  # later...
  
  # load the model
  #super_model <- readRDS(paste("results-classification/modelfit-",modelFit$method, ".rds", sep = ""))
  
  #plot(varImp(modelFit, scale=FALSE))
  
  #plot(modelFit)
}