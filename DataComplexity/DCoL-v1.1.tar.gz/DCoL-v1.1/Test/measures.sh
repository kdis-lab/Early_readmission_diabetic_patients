./dcol -i ./testList.dat -o ./Output/cM1nM1 -cM 1 -nM 1 -A -B -latex
./dcol -i ./testList.dat -o ./Output/cM1nM2 -cM 1 -nM 2 -A -B -latex
./dcol -i ./testList.dat -o ./Output/cM2nM1 -cM 2 -nM 1 -A -B -latex
./dcol -i ./testList.dat -o ./Output/cM2nM2 -cM 2 -nM 2 -A -B -latex
./dcol -i ./testList.dat -o ./Output/cM3nM1 -cM 3 -nM 1 -A -B -latex
./dcol -i ./testList.dat -o ./Output/cM3nM2 -cM 3 -nM 2 -A -B -latex
